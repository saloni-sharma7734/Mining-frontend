import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const LoginForm = () => {
  const [loginData, setLoginData] = useState({
    username: '',
    password: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setLoginData({
      ...loginData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    console.log('Login submitted:', loginData);

   
    setIsSubmitted(true);
  };

  return (
    <div className="container mt-5">
      <div className="card p-4" style={{ maxWidth: '400px', margin: '0 auto', backgroundColor: '#333', color: '#ecf0f1',height:'400px' }}>
        <h2 className="text-center mb-4">Login</h2>
        {!isSubmitted ? (
          <div>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label htmlFor="username" className="form-label">
                  Username
                </label>
                <input
                  type="text"
                  placeholder='Enter Your Username'
                  className="form-control"
                  id="username"
                  name="username"
                  value={loginData.username}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="password" className="form-label">
                  Password
                </label>
                <input
                  type="password"
                  placeholder='Enter Your password'
                  className="form-control"
                  id="password"
                  name="password"
                  value={loginData.password}
                  onChange={handleChange}
                  required
                />
              </div>
              <button type="submit" className="btn btn-primary">
                Login
              </button>
            </form>
            <p className="text-center mt-3">
              Don't have an account? <a href="#">Sign Up</a>
            </p>
          </div>
        ) : (
          <div>
            <h3 className="text-center mb-4">Welcome back, {loginData.username}!</h3>
            
          </div>
        )}
      </div>
    </div>
  );
};

export default LoginForm;
