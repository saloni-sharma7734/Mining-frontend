import React from 'react';
import { useSpring, animated } from 'react-spring';
import Header from './header';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import mineImage from '../images/mining1.jpg';
import { FaCheckCircle } from 'react-icons/fa';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import Footer from './footer';

const Home = () => {
  const fadeIn = useSpring({
    from: { opacity: 0 },
    to: { opacity: 1 },
    config: { duration: 1000 },
  });
  

  return (
    <div className="home-container">
      <Header />
      <animated.div style={fadeIn}>
        <div className="container mt-4">
          <div className="row">
            <div className="col-md-6">
              <h1 className="display-4"><b>Welcome to MineCare.</b></h1>
              <p className="lead">Your Trusted Mining Consultancy Partner!</p>
              <p className="lead">
                At our Mining Consultancy, we stand at the forefront of the mining industry, offering unparalleled expertise and innovative solutions to drive success for your mining ventures. With a passion for excellence and a commitment to sustainable practices, we are your go-to partner for navigating the complexities of the mining landscape.
              </p>
              <div className="mb-4">
                <h5>Why Choose Us?</h5>
                <ul className="list-unstyled">
                  <li><FaCheckCircle className="text-success" /> Mining Plan</li>
                  <li><FaCheckCircle className="text-success" /> Environment clearance</li>
                  <li><FaCheckCircle className="text-success" /> Environmentally Friendly Practices</li>
                  <li><FaCheckCircle className="text-success" /> Pollution clearance</li>
                  <li><FaCheckCircle className="text-success" /> New Lease</li>
                </ul>
              </div>
            </div>
            <div className="col-md-6">
              <img src="https://img.freepik.com/free-photo/dump-truck-pit-mine_181624-60225.jpg?w=1060&t=st=1702040057~exp=1702040657~hmac=c0be9e0648642f57e3a00d09648f533e0b4153188a91e36d49c4c91b0d5dbc5e" alt="Mining" className="img-fluid rounded" />
            </div>
          </div>

          <hr className="my-4" />

          <div className="colored-div" style={{ background: 'linear-gradient(to right, #e5e5e5, #f5f5f5 50%, #e5e5e5)', height: '400px', width: '100%', marginBottom: '20px' }}>
            <div className="container">
              <h2 className="text-center mt-4">Our Services</h2>
              <p className="lead text-center">Explore our comprehensive mining services tailored to meet your unique needs.</p>

              <div className="row mt-4">
                <div className="col-md-4">
                  <h3>Mining Plan</h3>
                  <p>
                    Our expert team will assist you in developing a strategic mining plan that maximizes resource extraction while adhering to environmental regulations.
                  </p>
                  <button className='btn btn-dark'>Learn More</button>
                </div>
                <div className="col-md-4">
                  <h3>Environmental Clearance</h3>
                  <p>
                    Navigate the regulatory landscape seamlessly with our assistance in obtaining environmental clearances for your mining projects.
                  </p>
                  <button className='btn btn-dark'>Learn More</button>
                </div>
                <div className="col-md-4">
                  <h3>Sustainable Practices</h3>
                  <p>
                    Embrace environmentally friendly mining practices with our guidance, ensuring sustainability and responsible resource management.
                  </p>
                  <button className='btn btn-dark'>Learn More</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </animated.div>
      <Footer />
    </div>
  );
};

export default Home;
