import React from 'react';
import { Link } from 'react-router-dom';
import Logo from '../images/black_white_nature_logo-removebg-preview.png'

const Header = () => {
    return (
        <nav className="navbar navbar-expand-lg navbar-light bg-light px-3">
            <Link className="navbar-brand" to="/">
            {/* <img src={Logo} alt="Your Logo" height={'90px'}/> */}
            MineCare
            </Link>

            <button
                className="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNav"
                aria-controls="navbarNav"
                aria-expanded="false"
                aria-label="Toggle navigation"
            >
                <span className="navbar-toggler-icon"></span>
            </button>

            <div className="collapse navbar-collapse" id="navbarNav">
                <ul className="navbar-nav ml-auto">
                    <li className="nav-item">
                        <Link className="nav-link" to="/home">
                            Home
                        </Link>
                    </li>

                    {/* <li className="nav-item">
                        <Link className="nav-link" to="/about">
                            About
                        </Link>
                    </li> */}
                    <li className="nav-item">
                        <Link className="nav-link" to="/services">
                            Services
                        </Link>
                    </li>

                
                    {/* <li className="nav-item dropdown">
                        <div className="dropdown">
                            <button className="nav-link dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Materials
                            </button> */}
                            
                            {/* <div className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <Link className="dropdown-item" to="/kaolin">
                                    Kaolin
                                </Link>
                                <Link className="dropdown-item" to="/Ballclay">
                                    Ball Clay
                                </Link>
                                <Link className="dropdown-item" to="clay">
                                    Clay(Other)
                                </Link>
                                <Link className="dropdown-item" to="Shale">
                                    Shale
                                </Link>
                            </div> */}
                        {/* </div>
                    </li> */}

                    <li className="nav-item">
                        <Link className="nav-link" to="/contact">
                            Contact
                        </Link>
                    </li>
                    {/* <li className="nav-item">
                        <Link className="nav-link" to="/login">
                            Login
                        </Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="/Signupform">
                            Signup
                        </Link>
                    </li> */}
                </ul>
            </div>
        </nav>
    );
};

export default Header;
