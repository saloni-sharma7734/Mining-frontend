import React from 'react';
import { useSpring, animated } from 'react-spring';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import example from '../images/mining1.jpg'
import Header from './header';
import { FaCheckCircle } from 'react-icons/fa';
import Footer from './footer';

// Sample data for mining services
const services = [
  {
    title: 'Mining Plan',
    description: 'Comprehensive mining plans tailored to your project needs.',
    image: '../images/mining1.jpg',
  },
  {
    title: 'Environment Clearance',
    description: 'Navigating regulatory requirements for environmental compliance.',
    image: '/path/to/environment_clearance_image.jpg',
  },
  {
    title: 'Environmentally Friendly Practices',
    description: 'Implementing sustainable and eco-friendly mining practices.',
    image: '/path/to/environment_friendly_image.jpg',
  },
  {
    title: 'Pollution Clearance',
    description: 'Ensuring compliance with pollution control regulations.',
    image: '/path/to/pollution_clearance_image.jpg',
  },
  {
    title: 'New Lease',
    description: 'Assistance in obtaining new mining leases and permits.',
    image: '/path/to/new_lease_image.jpg',
  },
];

const ServiceCard = ({ title, description, image }) => {
  return (
    <div className="service-card">
      <img src={image} alt={title} />
      <div className="card-content">
        <h3>{title}</h3>
        <p>{description}</p>
      </div>
    </div>
  );
};

const MiningServicesPage = () => {
  const slideIn = useSpring({
    opacity: 1,
    transform: 'translateX(0)',
    from: { opacity: 0, transform: 'translateX(-100%)' },
  });

  return (
    <>
      <div className="mining-services-page">
        <Header />
        <animated.div style={slideIn}>
          <h1>Mining Services</h1>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla
            accumsan, metus ultrices eleifend gravida, nulla nunc varius lectus,
            nec rutrum justo nibh eu lectus.
          </p>
        </animated.div>

        {/* Image Slider (You can use a dedicated library like react-slick) */}
        <div className="image-slider">
          {/* Your image slides go here */}
          <img src="/path/to/image1.jpg" alt="Slide 1" />
          <img src="/path/to/image2.jpg" alt="Slide 2" />
          <img src="/path/to/image3.jpg" alt="Slide 3" />
        </div>

        {/* Additional content */}
        <div className="additional-content">
          <p>
            Explore our comprehensive mining services designed to meet the
            industry's highest standards. Whether it's exploration,
            environmental impact assessments, or resource estimation, we have
            you covered.
          </p>
        </div>

        {/* Mining Services */}
        <div className="services-section">
          <h2>Our Services</h2>
          <div className="service-cards">
            {services.map((service, index) => (
              <ServiceCard key={index} {...service} />
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default MiningServicesPage;
